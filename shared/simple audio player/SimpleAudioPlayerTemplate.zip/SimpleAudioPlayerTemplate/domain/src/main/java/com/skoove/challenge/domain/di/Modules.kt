package com.skoove.challenge.domain.di

import org.koin.dsl.module

object Modules {

    val common = module {
        // Add domain specific dependencies here
    }

}
