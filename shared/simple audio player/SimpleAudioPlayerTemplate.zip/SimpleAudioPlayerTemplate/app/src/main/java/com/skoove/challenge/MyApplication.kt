package com.skoove.challenge

import android.app.Application

class MyApplication : Application()
